//
//  LearnSightfulApp.swift
//  LearnSightful
//
//  Created by sadeem faisal on 30/04/2023.
//

import SwiftUI

@main
struct LearnSightfulApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
